from uqpylab import sessions
import json 

myToken = '9a3596e05adc904b9ccf799b7466b407870b56c1' 
UQCloud_instance = 'https://beta.uq-cloud.io' 
mySession = sessions.cloud(host=UQCloud_instance, token=myToken)
uq = mySession.cli
mySession.reset()

iOpts = {'Marginals': uq.StdNormalMarginals(2) + 
                      uq.Marginals(1, 'Exponential', [1.5], flatten=False)}
# iOpts['Copula'] = uq.GaussianCopula([[1, .5, -.3], [.5, 1, .2],[-.3, .2, 1]], 'Linear') # the script works with a Gaussian copula
iOpts['Copula'] = uq.VineCopula('Cvine', [2,1,3],['t', 'Frank', 'Independence'],[[.4, 2], .5, None]) # but it doesn't work with a Vine copula
# iOpts['Copula'] = uq.VineCopula('Cvine', [2,1,3],['t', 'Frank', 'Frank'],[[.4, 2], .5, 0.1]) # but it doesn't work with a Vine copula

myInput = uq.createInput(iOpts)
# This line fixes it:
# myInput['Copula']['Parameters'].append(None)
import pdb; pdb.set_trace()
uq.CopulaSummary(myInput['Copula'])




