import pytest
import uqpylab.sessions as uq_session
import numpy as np


def model(X):
    return X*np.sin(X)

def create_model_and_check_display(uq, name, MetaOpts):
    print(f"Computing a {name} metamodel...")
    myMeta = uq.createModel(MetaOpts)
    print("Done.")
    print(f"Checking display functionality...")
    uq.display(myMeta)
    print("All good.")

@pytest.mark.skip(reason="Leaves garbage (open figures) in current version")
def test_PCE_display(request, helpers):
    mySession = helpers.init_session(request)
    uq = mySession.cli
    # Prepare the experimental design
    # & validation set from a simple model
    m_i = {
            'Type':'Uniform',
            'Parameters' : [-np.pi, np.pi]
            }
    InputOpts = {
        'Marginals': [m_i for i in [0,1,2] ]
        }
    print("Creating the input...")
    myInput = uq.createInput(InputOpts)
    print("Done.")
    
    print("Generating samples...")
    X_val = uq.getSample(N=1000)
    print("Done.")

    # create a default model
    print("Creating a true model object...")
    ModelOpts = {'Type' : 'Model',
        'ModelFun': 'uqpylab.test.true_models.ishigami'}
    myModel = uq.createModel(ModelOpts)
    print("Done.")
    print("Doing some model evaluations...")
    Y_val = model(X_val)
    print("Done.")

    # do quadrature PCE
    MetaOptsPCE = {
        'Type': 'Metamodel',
        'MetaType' : 'PCE',
        'FullModel': myModel['Name'],
        'Input': myInput['Name'],
        'Method' : 'Quadrature',
        'Degree' : 14
    }
    create_model_and_check_display(uq, "Quadrature PCE", MetaOptsPCE)
    
    print("Test complete.")
    
