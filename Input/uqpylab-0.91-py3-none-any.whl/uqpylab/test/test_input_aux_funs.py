import pytest
import uqpylab.sessions as uq_session
#from uqlab_standalone import sessions as uq_session

def test_input_aux_funs(request, helpers):
    mySession = helpers.init_session(request)
    uq = mySession.cli
    uq.rng(100, 'twister')
    iOptsTrue = {
        'Marginals': [
            {
                'Type': 'Gaussian',
                'Parameters': [-1,1]
            },
            {
                'Type': 'Exponential',
                'Parameters': [1]
            },
            {
                'Type': 'Uniform',
                'Parameters': [-1,3]
            }
        ]
    }
    myInputTrue = uq.createInput(iOptsTrue)

    X = uq.getSample(myInputTrue,200)

    iOpts = {
        'Inference': 
            {
                'Data': X.tolist()
            },
    }
    iOpts['Copula'] = {
        'Type': 'auto',
        'Inference': {
            'BlockIndepTest': {
                'Alpha': 0.05
            }
        },
        'Parameters': []
    }
    InputHat1c = uq.createInput(iOpts)
    
    # make sure that the session is properly terminated (no dangling background stuff)
    assert X.shape == (200,3)

def test_marginal_funs(request, helpers):
    mySession = helpers.init_session(request)
    uq = mySession.cli
    uq.rng(100, 'twister')

    iOptsTrue = {       
        'Marginals': [
            {
                'Type': 'Gaussian',
                'Parameters': [-1,1]
            },
            {
                'Type': 'Exponential',
                'Parameters': [1]
            },
            {
                'Type': 'Uniform',
                'Parameters': [-1,3]
            }
        ]
    }

    # myInputTrue = uq.createInput(iOptsTrue, response_format='JSON')
    myInputTrue = uq.createInput(iOptsTrue)

    X = uq.getSample(myInputTrue,200, response_format='JSON')
    # pytest.set_trace()
    U = uq.all_cdf(X, myInputTrue['Marginals'], request_format='JSON', response_format='JSON')
    assert X.shape == U.shape