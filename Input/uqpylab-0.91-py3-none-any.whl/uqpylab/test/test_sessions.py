import pytest
import uqpylab.sessions as uq_session
#from uqlab_standalone import sessions as uq_session

def start_a_session(host_spec, token_spec):
    if host_spec and token_spec:
        print(f"Connecting to UQCloud host: {host_spec}, with token: {token_spec}")
        return uq_session.cloud(host=host_spec,token=token_spec, log_level='DEBUG')
    else:
        print("Using remote UQCloud")
        return uq_session.cloud(log_level='DEBUG')
def test_session_start_stop(request, helpers):
    print("Starting a session...")
    mySession = helpers.init_session(request)
    print("Quiting the session...")
    mySession.quit()
    print("Starting a session again...")
    mySession = helpers.init_session(request)
    print("All good.")