import pytest
import uqpylab.sessions as uq_session
#from uqlab_standalone import uqlab
import numpy as np

@pytest.mark.skip(reason="Temporary")
def test_analysis(request,helpers):
    mySession = helpers.init_session(request)
    uq = mySession.cli
    # Prepare the experimental design
    # & validation set from a simple model
    InputOpts = {
        'Marginals': [
            {
            'Name':'X1',
            'Type':'Gaussian',
            'Parameters' : [0.25, 1]
            },
            {
            'Name':'X2',
            'Type':'Gaussian',
            'Parameters' : [0.25, 1]
            }]
        }
    print("Creating an input...")
    uq.createInput(InputOpts)
    print("Done.")
    print("Creating a true model object...")
    ModelOpts = {'Type' : 'Model',
        'ModelFun': 'uqpylab.test.true_models.hat2d'}
    #MCSOpts.Type = 'Reliability'
    myModel = uq.createModel(ModelOpts)
    print("Done.")
    # do an AK-MCS analysis
    AKMCSOpts = {
        'Type': 'Reliability',
        'Method' : 'AKMCS',
        'Simulation': {
            'MaxSampleSize': 1e5},
        'AKMCS': {
            'MaxAddedED' : 20,
            'IExpDesign':{
                'N': 20,
                'Sampling': 'LHS',
            },
            'Kriging':{
                'Corr':{
                    'Family': 'Gaussian'
                }
            },
        'Convergence': 'stopPf',
        'LearningFunction': 'EFF'
        },
    }
    print("Starting an AKMCS analysis...")
    myAKMCSAnalysis = uq.createAnalysis(AKMCSOpts)
    print("Done.")
    assert myAKMCSAnalysis['Results']['Pf'] < 0.001
    print("Done.")


def test_sse_reliability(request, helpers):
    mySession = helpers.init_session(request)
    uq = mySession.cli
    print("Creating an input...")
    InputOpts = {
            "Marginals": [
                {"Name": "R",               # Resistance
                "Type": "Gaussian",
                "Moments": [5.0 , 0.8]
                },
                {"Name": "S",               # Stress
                "Type": "Gaussian",
                "Moments": [2.0 , 0.6]
                }
            ]
        }
    myInput = uq.createInput(InputOpts)
    print("Done.")
    print("Creating a model...")
    ModelOpts = { 
        'Type': 'Model', 
        'mString': 'X(:,1) - X(:,2)',
        'isVectorized': 1
    }
    myModel = uq.createModel(ModelOpts)
    print("Done.")
    SSEROpts = {
    "Type": "Reliability",
    "Method": "SSER"
    }
    print("Performing SSE Reliability...")
    SSERAnalysis = uq.createAnalysis(SSEROpts)
    print("Done.")
    print("Testing print...")
    uq.print(SSERAnalysis)
    pytest.set_trace()
    print("Testing display...")
    uq.display(SSERAnalysis)
    print("All good.")




